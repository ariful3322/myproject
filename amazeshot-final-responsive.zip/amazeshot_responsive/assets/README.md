# /assets/

Place shared assets here (logos, images, icons).
This folder is intentionally empty in the base project.
